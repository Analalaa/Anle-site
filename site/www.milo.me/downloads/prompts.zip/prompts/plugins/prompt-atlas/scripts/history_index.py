"""Read-only Codex history reader with a private, disposable SQLite search cache.

Only display messages are indexed. Source history and the app database are never
modified; reasoning, tools, credentials and injected instructions are excluded.
"""
import hashlib
import json
import os
import re
import sqlite3
import threading
from datetime import datetime, timezone, timedelta
from contextlib import contextmanager, closing
from pathlib import Path


_INJECTED = re.compile(
    r"^\s*(?:# AGENTS\.md\b|<(?:(?:environment_context|recommended_plugins|"
    r"in-app-browser-context|app-context|permissions|skills_instructions|"
    r"user_instructions|developer_instructions|system_reminder|context_summary|"
    r"collaboration_mode|multi_agent_role|multi_agent_mode)(?:\s|>)))", re.I
)
_ALLOWED_PHASES = {None, "", "final", "final_answer", "commentary"}
_PARSER_VERSION = "4"
_BROWSER_BLOCK = re.compile(r"<in-app-browser-context\b([^>]*)>(.*?)</in-app-browser-context\s*>", re.I | re.S)


def _strip_ambient(text):
    def replace(match):
        attributes, body = match.groups()
        marked = re.search(r'''\bsource\s*=\s*["']ambient-ui-state["']''', attributes, re.I)
        supplied = body.lstrip().startswith("This block is automatically supplied ambient UI state")
        return "" if marked or supplied else match.group(0)
    return _BROWSER_BLOCK.sub(replace, text).strip()


def _json(path, default):
    try:
        with path.open("r", encoding="utf-8") as stream:
            return json.load(stream)
    except (OSError, ValueError):
        return default


def _timestamp(value):
    if isinstance(value, (int, float)):
        if value > 100000000000:
            value /= 1000
        return datetime.fromtimestamp(value, timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")
    if not value:
        return ""
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).astimezone(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")
    except (ValueError, OverflowError):
        return str(value)


def _path(value):
    return os.path.normcase(os.path.realpath(os.path.expanduser(str(value)))) if value else ""


def _within(path, root):
    return bool(root and (path == root or path.startswith(root.rstrip(os.sep) + os.sep)))


def _literal(value):
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def _date_boundary(value, end=False):
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", value or ""):
        # A naive date is deliberately interpreted in the user's OS time zone;
        # astimezone consults the offset for that date, including DST.
        instant = datetime.fromisoformat(value)
        if end:
            instant += timedelta(days=1)
        return _timestamp(instant.astimezone(timezone.utc).isoformat()), end
    return _timestamp(value), False


def _terms(query):
    # Quoted phrases and whitespace-separated literals, never SQL/FTS syntax.
    return [a or b for a, b in re.findall(r'"([^"]+)"|(\S+)', query or "")][:30]


def _text(content, user=False, kinds=None):
    if isinstance(content, str):
        content = _strip_ambient(content)
        return "" if user and _INJECTED.match(content) else content.strip()
    if not isinstance(content, list):
        return ""
    parts = []
    for index, item in enumerate(content):
        if not isinstance(item, dict) or item.get("type") not in {"text", "Text", "input_text", "output_text"}:
            continue
        if kinds is not None and len(kinds) == len(content) and kinds[index] not in {"user.text", "unknown"}:
            continue
        text = item.get("text", "")
        if isinstance(text, str):
            text = _strip_ambient(text)
        if isinstance(text, str) and text.strip() and not (user and _INJECTED.match(text)):
            parts.append(text.strip())
    return "\n\n".join(parts)


class HistoryIndex:
    def __init__(self, codex_home: Path, cache_dir: Path, current_project: str = ""):
        self.codex_home = Path(codex_home).expanduser().resolve()
        self.cache_dir = Path(cache_dir).expanduser().resolve()
        self.cache_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.cache_path = self.cache_dir / "history.sqlite3"
        self.current_project = current_project
        self._lock = threading.RLock()
        self._indexing = False
        self._warnings = []
        self._last_indexed = ""
        with self._db() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS files (
                    path TEXT PRIMARY KEY, size INTEGER, mtime_ns INTEGER,
                    inode INTEGER, thread_id TEXT);
                CREATE TABLE IF NOT EXISTS threads (
                    id TEXT PRIMARY KEY, title TEXT, project TEXT,
                    project_name TEXT, project_path TEXT, cwd TEXT,
                    archived INTEGER, subagent INTEGER, updated_at TEXT);
                CREATE TABLE IF NOT EXISTS messages (
                    id TEXT PRIMARY KEY, thread_id TEXT, source_path TEXT,
                    role TEXT, channel TEXT, text TEXT, timestamp TEXT,
                    position INTEGER);
                CREATE INDEX IF NOT EXISTS messages_thread ON messages(thread_id, position);
                CREATE INDEX IF NOT EXISTS messages_time ON messages(timestamp DESC);
                CREATE INDEX IF NOT EXISTS messages_source ON messages(source_path);
                CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT);
            """)
            row = db.execute("SELECT value FROM metadata WHERE key='last_indexed'").fetchone()
            self._last_indexed = row[0] if row else ""
        try:
            self.cache_path.chmod(0o600)
        except OSError:
            pass

    @contextmanager
    def _db(self):
        db = sqlite3.connect(str(self.cache_path), timeout=20)
        db.row_factory = sqlite3.Row
        try:
            with db:
                yield db
        finally:
            db.close()

    def _warn(self, text):
        if text not in self._warnings:
            self._warnings.append(text)

    def _source_metadata(self):
        records, projects, aliases = {}, {}, {}
        # App schema evolves; introspect and read only the fields we need.
        sources = sorted(self.codex_home.glob("state_*.sqlite"), key=lambda p: int(re.search(r"(\d+)\.sqlite$", p.name).group(1)), reverse=True)
        for source in sources:
            try:
                with closing(sqlite3.connect(source.as_uri() + "?mode=ro", uri=True, timeout=2)) as db:
                    db.row_factory = sqlite3.Row
                    columns = {r[1] for r in db.execute("PRAGMA table_info(threads)")}
                    wanted = [k for k in ("id", "rollout_path", "cwd", "title", "name", "archived", "source", "project_id", "updated_at_ms", "updated_at") if k in columns]
                    if "id" not in wanted:
                        continue
                    records = {r["id"]: dict(r) for r in db.execute("SELECT " + ",".join(wanted) + " FROM threads")}
                    tables = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                    if "projects" in tables:
                        for row in db.execute("SELECT id,name FROM projects"):
                            projects[row["id"]] = {"id": row["id"], "name": row["name"], "roots": []}
                    if "project_roots" in tables:
                        for row in db.execute("SELECT project_id,path FROM project_roots ORDER BY position"):
                            if row["project_id"] in projects:
                                projects[row["project_id"]]["roots"].append(_path(row["path"]))
                break
            except (OSError, sqlite3.Error) as exc:
                self._warn("无法读取部分项目元数据；已使用会话文件。" + type(exc).__name__)
        state = _json(self.codex_home / ".codex-global-state.json", {})
        if not isinstance(state, dict):
            state = {}
        for mapping in state.get("app-server-project-id-by-legacy-project-id-by-host", {}).values():
            if isinstance(mapping, dict):
                aliases.update({k: v for k, v in mapping.items() if isinstance(v, str) and v in projects})
        for old_id, project in state.get("local-projects", {}).items():
            if not isinstance(project, dict):
                continue
            project_id = aliases.get(old_id, old_id)
            current = projects.setdefault(project_id, {"id": project_id, "name": project.get("name") or old_id, "roots": []})
            for root in project.get("rootPaths", []):
                if isinstance(root, str) and _path(root) not in current["roots"]:
                    current["roots"].append(_path(root))
        index_path = self.codex_home / "session_index.jsonl"
        try:
            with index_path.open(encoding="utf-8") as stream:
                for line in stream:
                    try:
                        row = json.loads(line)
                        record = records.setdefault(row["id"], {"id": row["id"]})
                        if not record.get("title"):
                            record["title"] = row.get("thread_name", "")
                    except (ValueError, KeyError, TypeError):
                        continue
        except OSError:
            pass
        return records, projects, aliases, state

    def _project(self, thread_id, meta, record, projects, aliases, state):
        cwd = _path(record.get("cwd") or meta.get("cwd"))
        project_id = record.get("project_id")
        assignment = state.get("thread-project-assignments", {}).get(thread_id, {})
        if not project_id and isinstance(assignment, dict) and assignment.get("projectKind") == "local":
            project_id = assignment.get("projectId")
        project_id = aliases.get(project_id, project_id)
        if project_id in projects:
            project = projects[project_id]
            return project_id, project["name"], next(iter(project["roots"]), cwd), cwd
        if thread_id in state.get("projectless-thread-ids", []):
            return "__projectless__", "未分配项目", "", cwd
        candidates = [cwd]
        hints = state.get("thread-workspace-root-hints", {}).get(thread_id)
        if isinstance(hints, str):
            candidates.append(_path(hints))
        # A managed worktree's .git points to <repository>/.git/worktrees/<id>.
        # Reading this small pointer keeps worktrees grouped with their repo.
        try:
            git_pointer = Path(cwd) / ".git"
            if git_pointer.is_file():
                pointer = git_pointer.read_text(encoding="utf-8").strip()
                if pointer.startswith("gitdir: "):
                    git_dir = (Path(cwd) / pointer[8:]).resolve()
                    common = git_dir / "commondir"
                    if common.is_file():
                        common_dir = (git_dir / common.read_text(encoding="utf-8").strip()).resolve()
                        if common_dir.name == ".git":
                            candidates.append(str(common_dir.parent))
        except OSError:
            pass
        matches = [(len(root), p) for p in projects.values() for root in p["roots"] if any(_within(c, root) for c in candidates)]
        if matches:
            project = max(matches, key=lambda match: match[0])[1]
            return project["id"], project["name"], next(iter(project["roots"]), cwd), cwd
        root = candidates[-1] or cwd
        return root or "__projectless__", Path(root).name if root else "未分配项目", root, cwd

    def _parse(self, path):
        rows, meta = [], {}
        malformed = False
        with path.open("r", encoding="utf-8", errors="replace") as stream:
            for position, line in enumerate(stream):
                try:
                    row = json.loads(line)
                    if not isinstance(row, dict) or not isinstance(row.get("payload"), dict):
                        continue
                    rows.append((position, row))
                    if row.get("type") == "session_meta" and not meta:
                        # Forked histories embed a second session_meta from the
                        # parent. Only the file's first header owns its identity.
                        meta = dict(row["payload"])
                except ValueError:
                    malformed = True
        if malformed:
            self._warn("部分历史行未写完或格式无效，已跳过；下次刷新会重试。")
        thread_id = meta.get("id") or meta.get("session_id")
        if not thread_id:
            match = re.search(r"([0-9a-f]{8}-[0-9a-f-]{27,})", path.stem, re.I)
            thread_id = match.group(1) if match else None
        if not thread_id:
            return None, meta, []
        events, responses, turn_id = [], [], ""
        for position, row in rows:
            inherited_boundary = meta.get("subagent_history_start_ordinal")
            if isinstance(inherited_boundary, int) and isinstance(row.get("ordinal"), int) and row["ordinal"] < inherited_boundary:
                continue
            payload = row["payload"]
            kind = row.get("type")
            if kind == "turn_context" or (kind == "event_msg" and payload.get("type") == "task_started"):
                turn_id = payload.get("turn_id", turn_id)
            stamp = row.get("timestamp", "")
            if kind == "event_msg" and payload.get("type") == "item_completed":
                item = payload.get("item", {})
                if not isinstance(item, dict) or item.get("type") not in {"UserMessage", "AgentMessage", "userMessage", "agentMessage"}:
                    continue
                if payload.get("thread_id") and payload["thread_id"] != thread_id:
                    continue
                role = "user" if item["type"].lower() == "usermessage" else "assistant"
                phase = item.get("phase") or item.get("channel") or payload.get("phase") or payload.get("channel")
                if phase not in _ALLOWED_PHASES:
                    continue
                text = _text(item.get("content") or item.get("text", ""))
                events.append((position, payload.get("turn_id") or turn_id, item.get("id"), role, phase, text, payload.get("completed_at_ms") or stamp))
            elif kind == "event_msg" and payload.get("type") in {"user_message", "agent_message"}:
                role = "user" if payload["type"] == "user_message" else "assistant"
                phase = payload.get("phase") or payload.get("channel")
                if phase not in _ALLOWED_PHASES:
                    continue
                text = _text(payload.get("message", ""))
                events.append((position, payload.get("turn_id") or turn_id, payload.get("id"), role, phase, text, stamp))
            elif kind == "response_item" and payload.get("type") == "message" and payload.get("role") in {"user", "assistant"}:
                role = payload["role"]
                phase = payload.get("phase") or payload.get("channel")
                if phase not in _ALLOWED_PHASES:
                    continue
                passthrough = payload.get("internal_chat_message_metadata_passthrough") or {}
                if not isinstance(passthrough, dict):
                    passthrough = {}
                kinds = passthrough.get("content_item_kinds") if role == "user" else None
                text = _text(payload.get("content"), user=role == "user", kinds=kinds)
                responses.append((position, passthrough.get("turn_id") or turn_id, payload.get("id"), role, phase, text, passthrough.get("create_time") or stamp))
        covered_turns = {(r[1], r[3]) for r in events if r[1]}
        covered_text = {(r[3], r[5]) for r in events}
        covered_assistant = {(r[1], r[5], r[4] == "commentary") for r in events if r[3] == "assistant"}
        candidates = list(events)
        for response in responses:
            if response[3] == "user" and (response[1], response[3]) in covered_turns:
                continue
            if response[3] == "assistant" and (response[1], response[5], response[4] == "commentary") in covered_assistant:
                continue
            if not response[1] and (response[3], response[5]) in covered_text:
                continue
            candidates.append(response)
        candidates.sort(key=lambda row: row[0])
        messages, seen = [], set()
        for position, turn, native_id, role, phase, text, stamp in candidates:
            if not text:
                continue
            channel = "commentary" if phase == "commentary" else "final"
            identity = (role, turn, native_id) if native_id else (role, turn, channel, text) if turn else (role, position)
            if identity in seen:
                continue
            seen.add(identity)
            digest = hashlib.sha256((str(thread_id) + "\0" + repr(identity)).encode()).hexdigest()[:24]
            messages.append({"id": digest, "thread_id": thread_id, "role": role, "channel": channel,
                             "text": text, "timestamp": _timestamp(stamp), "position": position})
        return thread_id, meta, messages

    def refresh(self):
        with self._lock:
            self._indexing = True
            self._warnings = []
            try:
                records, projects, aliases, state = self._source_metadata()
                paths, complete_scan = set(), self.codex_home.is_dir()
                if not complete_scan:
                    self._warn("Codex 历史目录不可用，已保留此前的索引。")
                for directory in ("sessions", "archived_sessions"):
                    base = self.codex_home / directory
                    if not base.exists():
                        continue
                    def walk_error(error):
                        nonlocal complete_scan
                        complete_scan = False
                        self._warn("部分历史目录无法读取，已保留此前的索引。")
                    for current, _, names in os.walk(str(base), onerror=walk_error):
                        paths.update(Path(current) / name for name in names if name.endswith(".jsonl"))
                for record in records.values():
                    if record.get("rollout_path"):
                        candidate = Path(record["rollout_path"]).expanduser()
                        # Only read history files under this Codex home.
                        if candidate.suffix == ".jsonl" and _within(str(candidate.resolve()), str(self.codex_home)) and candidate.exists():
                            paths.add(candidate)
                with self._db() as db:
                    parser_row = db.execute("SELECT value FROM metadata WHERE key='parser_version'").fetchone()
                    force_reparse = not parser_row or parser_row[0] != _PARSER_VERSION
                    reparse_complete = complete_scan
                    cached = {r["path"]: dict(r) for r in db.execute("SELECT * FROM files")}
                    seen = set()
                    for path in sorted(paths):
                        filename = str(path)
                        seen.add(filename)
                        try:
                            stat = path.stat()
                            previous = cached.get(filename)
                            changed = force_reparse or not previous or (previous["size"], previous["mtime_ns"], previous["inode"]) != (stat.st_size, stat.st_mtime_ns, stat.st_ino)
                            if changed:
                                thread_id, meta, messages = self._parse(path)
                                if not thread_id:
                                    reparse_complete = False
                                    continue
                                db.execute("DELETE FROM messages WHERE source_path=?", (filename,))
                                for message in messages:
                                    db.execute("INSERT OR REPLACE INTO messages VALUES(?,?,?,?,?,?,?,?)", (message["id"], thread_id, filename, message["role"], message["channel"], message["text"], message["timestamp"], message["position"]))
                                db.execute("INSERT OR REPLACE INTO files VALUES(?,?,?,?,?)", (filename, stat.st_size, stat.st_mtime_ns, stat.st_ino, thread_id))
                            else:
                                thread_id = previous["thread_id"]
                                # Metadata is small and may be needed after project moves.
                                meta = {}
                                with path.open(encoding="utf-8", errors="replace") as stream:
                                    for _ in range(6):
                                        line = stream.readline()
                                        if not line:
                                            break
                                        try:
                                            row = json.loads(line)
                                            if row.get("type") == "session_meta":
                                                meta = row.get("payload", {})
                                                break
                                        except ValueError:
                                            pass
                            record = records.get(thread_id, {})
                            project_id, project_name, project_path, cwd = self._project(thread_id, meta, record, projects, aliases, state)
                            source = record.get("source") or meta.get("source") or ""
                            subagent = bool(meta.get("parent_thread_id") or (meta.get("agent_path") and meta.get("agent_path") != "/root") or (isinstance(source, dict) and "subagent" in source) or (isinstance(source, str) and ("subagent" in source or source == "guardian")))
                            archived = bool(record.get("archived") or "archived_sessions" in path.parts)
                            title = record.get("title") or record.get("name")
                            if not title:
                                first = db.execute("SELECT text FROM messages WHERE thread_id=? AND role='user' ORDER BY position LIMIT 1", (thread_id,)).fetchone()
                                title = first[0][:100] if first else "未命名任务"
                            updated = _timestamp(record.get("updated_at_ms") or record.get("updated_at") or stat.st_mtime)
                            db.execute("INSERT OR REPLACE INTO threads VALUES(?,?,?,?,?,?,?,?,?)", (thread_id, title, project_id, project_name, project_path, cwd, int(archived), int(subagent), updated))
                        except (OSError, UnicodeError) as exc:
                            reparse_complete = False
                            self._warn("部分历史文件无法读取，已保留此前的索引。" + type(exc).__name__)
                    if complete_scan:
                        for filename in set(cached) - seen:
                            db.execute("DELETE FROM messages WHERE source_path=?", (filename,))
                            db.execute("DELETE FROM files WHERE path=?", (filename,))
                    db.execute("DELETE FROM threads WHERE id NOT IN (SELECT thread_id FROM files)")
                    self._last_indexed = _timestamp(datetime.now(timezone.utc).timestamp())
                    db.execute("INSERT OR REPLACE INTO metadata VALUES('last_indexed',?)", (self._last_indexed,))
                    if reparse_complete:
                        db.execute("INSERT OR REPLACE INTO metadata VALUES('parser_version',?)", (_PARSER_VERSION,))
            finally:
                self._indexing = False
        return self.status()

    def _resolved_project(self, db, project):
        if not project:
            return ""
        row = db.execute("SELECT project FROM threads WHERE project=? OR project_path=? OR cwd=? LIMIT 1", (project, _path(project), _path(project))).fetchone()
        if row:
            return row[0]
        candidates = db.execute("SELECT DISTINCT project,project_path FROM threads WHERE project_path!=''").fetchall()
        matching = [r for r in candidates if _within(_path(project), r["project_path"])]
        return max(matching, key=lambda r: len(r["project_path"]))["project"] if matching else project

    def status(self):
        with self._lock, self._db() as db:
            project_id = self._resolved_project(db, self.current_project)
            row = db.execute("SELECT project_name FROM threads WHERE project=? LIMIT 1", (project_id,)).fetchone()
            return {"threads": db.execute("SELECT count(*) FROM threads WHERE subagent=0").fetchone()[0],
                    "messages": db.execute("SELECT count(*) FROM messages m JOIN threads t ON t.id=m.thread_id WHERE t.subagent=0").fetchone()[0],
                    "projects": db.execute("SELECT count(DISTINCT project) FROM threads WHERE subagent=0").fetchone()[0],
                    "last_indexed": self._last_indexed, "indexing": self._indexing, "warnings": list(self._warnings),
                    "current_project": project_id, "current_project_name": row[0] if row else Path(self.current_project).name}

    def projects(self):
        with self._lock, self._db() as db:
            rows = db.execute("SELECT t.project AS id,t.project_name AS name,t.project_path AS path,count(DISTINCT t.id) AS threads,count(m.id) AS messages FROM threads t LEFT JOIN messages m ON m.thread_id=t.id WHERE t.subagent=0 GROUP BY t.project ORDER BY name COLLATE NOCASE").fetchall()
            return {"projects": [dict(row) for row in rows]}

    def search(self, q="", project="", role="", after="", before="", archived=True,
               commentary=False, subagents=False, sort="recent", limit=40, offset=0):
        limit, offset = max(1, min(int(limit), 200)), max(0, int(offset))
        with self._lock, self._db() as db:
            conditions, params = [], []
            if project:
                if project in {"current", "__current__"}:
                    project = self.current_project
                conditions.append("t.project=?")
                params.append(self._resolved_project(db, project))
            if role in {"user", "assistant"}:
                conditions.append("m.role=?")
                params.append(role)
            if not archived:
                conditions.append("t.archived=0")
            if not subagents:
                conditions.append("t.subagent=0")
            if not commentary:
                conditions.append("m.channel!='commentary'")
            if after:
                conditions.append("m.timestamp>=?")
                params.append(_date_boundary(after)[0])
            if before:
                boundary, exclusive = _date_boundary(before, end=True)
                conditions.append("m.timestamp<?" if exclusive else "m.timestamp<=?")
                params.append(boundary)
            terms = _terms(q)
            for term in terms:
                conditions.append("m.text LIKE ? ESCAPE '\\'")
                params.append("%" + _literal(term) + "%")
            where = " WHERE " + " AND ".join(conditions) if conditions else ""
            relation = " FROM messages m JOIN threads t ON t.id=m.thread_id"
            total = db.execute("SELECT count(*)" + relation + where, params).fetchone()[0]
            direction = "ASC" if sort in {"oldest", "asc"} else "DESC"
            order = "m.timestamp " + direction + ",m.position " + direction + ",m.id"
            ranking_params = []
            if sort == "relevance" and terms:
                scores = []
                for term in terms:
                    scores.append("((length(lower(m.text))-length(replace(lower(m.text),lower(?),'')))*1.0/max(1,length(?)))")
                    ranking_params.extend([term, term])
                order = "(" + "+".join(scores) + ") DESC," + order
            rows = db.execute("SELECT m.id,m.thread_id,t.title,t.project,t.project_name,m.role,m.channel,m.text,m.timestamp,t.archived" + relation + where + " ORDER BY " + order + " LIMIT ? OFFSET ?", params + ranking_params + [limit, offset]).fetchall()
            results = []
            for row in rows:
                item = dict(row)
                item["archived"] = bool(item["archived"])
                item["deep_link"] = "codex://threads/" + item["thread_id"]
                text = item["text"]
                positions = [text.casefold().find(term.casefold()) for term in terms]
                found = min((p for p in positions if p >= 0), default=0)
                start = max(0, found - 70)
                item["snippet"] = ("…" if start else "") + text[start:start + 260] + ("…" if start + 260 < len(text) else "")
                results.append(item)
            return {"results": results, "total": total, "offset": offset, "limit": limit}

    def thread(self, thread_id, message_id="", offset=None, limit=101):
        limit = max(1, min(int(limit), 301))
        with self._lock, self._db() as db:
            row = db.execute("SELECT id,title,project,project_name FROM threads WHERE id=?", (thread_id,)).fetchone()
            if not row:
                raise KeyError(thread_id)
            rows = db.execute("SELECT id,role,channel,text,timestamp FROM messages WHERE thread_id=? ORDER BY position,id", (thread_id,)).fetchall()
            total = len(rows)
            if offset is None:
                focus = next((index for index, item in enumerate(rows) if item["id"] == message_id), total - 1)
                offset = max(0, min(focus - limit // 2, total - limit)) if message_id else max(0, total - limit)
            offset = max(0, int(offset))
            result = dict(row)
            result.update({"deep_link": "codex://threads/" + thread_id,
                           "messages": [dict(item) for item in rows[offset:offset + limit]],
                           "has_more_before": offset > 0, "has_more_after": offset + limit < total,
                           "offset": offset, "total": total})
            return result
