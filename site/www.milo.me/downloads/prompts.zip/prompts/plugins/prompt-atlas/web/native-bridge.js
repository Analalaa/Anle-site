/* Adapt the browser API to the Codex MCP App host. No history leaves the local plugin. */
(() => {
  "use strict";

  const globals = {};
  const nativeKeys = ["toolInput", "toolOutput", "toolResponseMetadata"];
  let resolveReady;
  let readyTimer;
  let readySettled = false;

  function captureGlobals(source) {
    if (!source || typeof source !== "object") return;
    for (const key of nativeKeys) {
      if (source[key] !== undefined) globals[key] = source[key];
    }
  }

  function unpack(response) {
    if (response == null) throw new Error("插件没有返回数据，请稍后重试。");
    const wrapped = response.result && typeof response.result === "object" &&
      (response.result.structuredContent !== undefined || Array.isArray(response.result.content));
    const value = wrapped ? response.result : response;
    const text = Array.isArray(value.content)
      ? value.content.filter(item => item && item.type === "text").map(item => item.text || "").join("\n")
      : "";
    if (value.isError) throw new Error(text || value.error || "插件读取失败，请稍后重试。");
    if (value.structuredContent && typeof value.structuredContent === "object") return value.structuredContent;
    if (text) {
      try { return JSON.parse(text); }
      catch (_) { throw new Error("插件返回的数据格式不完整，请刷新后重试。"); }
    }
    if (typeof value === "string") {
      try { return JSON.parse(value); }
      catch (_) { throw new Error("插件返回的数据格式不完整，请刷新后重试。"); }
    }
    if (typeof value === "object" && !Array.isArray(value.content)) return value;
    throw new Error("插件没有返回可读取的数据。");
  }

  function outputSnapshot() {
    captureGlobals(window.openai);
    try { return globals.toolOutput ? unpack(globals.toolOutput) : {}; }
    catch (_) { return {}; }
  }

  function context() {
    const output = outputSnapshot();
    const input = globals.toolInput || {};
    // An explicit empty project is the global entrypoint, not a missing value.
    const current = typeof output.current_project === "string" ? output.current_project
      : typeof input.current_project === "string" ? input.current_project
        : output.scope === "all" ? "" : output.status?.current_project || "";
    const scope = output.scope || input.scope;
    return {
      current_project: current,
      project: typeof output.project === "string" ? output.project
        : scope === "all" ? "" : input.project_path || current,
      q: output.query || output.q || input.query || ""
    };
  }

  function announceContext() {
    window.dispatchEvent(new CustomEvent("atlas:native-context", {detail: context()}));
  }

  function settleReady(available) {
    if (readySettled) return;
    readySettled = true;
    clearTimeout(readyTimer);
    resolveReady(available);
  }

  window.atlasNativeReady = new Promise(resolve => { resolveReady = resolve; });
  window.addEventListener("openai:set_globals", event => {
    captureGlobals(event.detail?.globals || event.detail);
    if (typeof window.openai?.callTool === "function") settleReady(true);
    announceContext();
  });
  captureGlobals(window.openai);
  if (typeof window.openai?.callTool === "function") settleReady(true);
  else if (window.ATLAS_NATIVE) readyTimer = setTimeout(() => settleReady(false), 3000);
  else settleReady(false);

  function checkAbort(signal) {
    if (signal?.aborted) throw new DOMException("请求已取消", "AbortError");
  }

  async function call(name, args, signal) {
    checkAbort(signal);
    if (typeof window.openai?.callTool !== "function") await window.atlasNativeReady;
    checkAbort(signal);
    if (typeof window.openai?.callTool !== "function") {
      throw new Error("Codex 面板尚未连接，请重新打开 Prompts。");
    }
    const value = unpack(await window.openai.callTool(name, args));
    checkAbort(signal);
    if (value.error) throw new Error(String(value.error));
    return value;
  }

  function number(params, key, fallback, maximum) {
    const raw = params.get(key);
    const parsed = raw === null || raw === "" ? fallback : Number(raw);
    if (!Number.isFinite(parsed)) return fallback;
    return Math.min(maximum, Math.max(key === "offset" ? 0 : 1, Math.trunc(parsed)));
  }

  function withContext(status) {
    const current = context().current_project;
    return {...status, current_project: current,
      current_project_name: current === status.current_project ? status.current_project_name || "" : ""};
  }

  window.atlasNativeContext = context;
  window.atlasNativeRequest = async (path, options = {}) => {
    const url = new URL(path, "https://prompt-atlas.local");
    const params = url.searchParams;
    const method = (options.method || "GET").toUpperCase();
    const signal = options.signal;
    if (url.pathname === "/api/status" && method === "GET") {
      return withContext(await call("atlas_status", {}, signal));
    }
    if (url.pathname === "/api/projects" && method === "GET") {
      const result = await call("atlas_projects", {}, signal);
      return {...result, status: withContext(result.status || {})};
    }
    if (url.pathname === "/api/refresh" && method === "POST") {
      return withContext(await call("atlas_refresh", {}, signal));
    }
    if (url.pathname === "/api/search" && method === "GET") {
      const project = params.get("project") || "";
      const args = {
        scope: project ? "project" : "all",
        query: params.get("q") || "",
        role: params.get("role") || "all",
        after: params.get("after") || "",
        before: params.get("before") || "",
        include_archived: params.get("archived") !== "0",
        include_commentary: params.get("commentary") === "1",
        include_subagents: params.get("subagents") === "1",
        sort: params.get("sort") || "recent",
        limit: number(params, "limit", 40, 50),
        offset: number(params, "offset", 0, Number.MAX_SAFE_INTEGER)
      };
      if (project) args.project_path = project;
      const result = await call("atlas_search", args, signal);
      return {...result, results: (result.results || []).map(item => ({
        ...item, text: item.text ?? item.snippet ?? ""
      }))};
    }
    if (url.pathname === "/api/thread" && method === "GET") {
      const args = {
        thread_id: params.get("id") || "",
        message_id: params.get("message") || "",
        limit: number(params, "limit", 101, 101)
      };
      if (params.has("offset")) args.offset = number(params, "offset", 0, Number.MAX_SAFE_INTEGER);
      return call("atlas_read_thread", args, signal);
    }
    throw new Error("此操作暂不支持在 Codex 面板中使用。");
  };

  window.atlasNativeOpenThread = async threadId => {
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(threadId)) {
      throw new Error("任务链接无效。");
    }
    if (typeof window.openai?.openExternal !== "function") await window.atlasNativeReady;
    if (typeof window.openai?.openExternal !== "function") throw new Error("Codex 暂时无法打开任务链接。");
    return window.openai.openExternal({href: `codex://threads/${encodeURIComponent(threadId)}`});
  };
})();
