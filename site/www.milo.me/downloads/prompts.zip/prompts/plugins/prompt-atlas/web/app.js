"use strict";

(() => {
  const $ = (id) => document.getElementById(id);
  const isNative = () => Boolean(window.ATLAS_NATIVE || window.openai?.callTool);
  const state = {
    token: "", status: null, projects: [], scope: "all", project: "", role: "all",
    query: "", sort: "recent", after: "", before: "", archived: true, commentary: false, subagents: false,
    results: [], total: 0, offset: 0, limit: 40, selectedId: null, thread: null,
    threadStart: 0, threadEnd: 0, hasBefore: false, hasAfter: false,
    searchController: null, threadController: null, debounce: null, polling: null,
    toastTimer: null, searching: false, ready: false, generation: 0, loadingContext: false, nativeContextSignature: "", launchContext: null,
    reading: false, listScroll: 0, theme: "light", themePreference: "",
  };

  function initializeTheme() {
    try {
      const saved = localStorage.getItem("here-are-my-prompts-theme");
      if (saved === "light" || saved === "dark") state.themePreference = saved;
    } catch (_) { /* Theme switching still works when the host disables storage. */ }
    const apply = (theme) => {
      state.theme = theme;
      document.documentElement.setAttribute("data-theme", theme);
      const label = theme === "dark" ? "切换至日间模式" : "切换至夜间模式";
      for (const button of document.querySelectorAll(".theme-toggle")) {
        button.setAttribute("aria-label", label);
        button.setAttribute("title", label);
      }
    };
    apply(state.themePreference || "light");
    for (const button of document.querySelectorAll(".theme-toggle")) button.addEventListener("click", () => {
      state.themePreference = state.theme === "dark" ? "light" : "dark";
      apply(state.themePreference);
      try { localStorage.setItem("here-are-my-prompts-theme", state.themePreference); } catch (_) {}
    });
  }

  function element(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = String(text);
    return node;
  }

  function initializeToken() {
    const hash = location.hash.slice(1);
    const params = new URLSearchParams(hash);
    const token = params.get("token");
    if (params.has("project") || params.has("current_project") || params.has("q")) {
      state.launchContext = {
        project: params.get("project") || "",
        current_project: params.get("current_project") || "",
        q: params.get("q") || "",
      };
    }
    try {
      if (token) sessionStorage.setItem("prompt-atlas-token", token);
      state.token = token || sessionStorage.getItem("prompt-atlas-token") || "";
      if (state.launchContext) sessionStorage.setItem("prompt-atlas-context", JSON.stringify(state.launchContext));
      else if (!isNative()) state.launchContext = JSON.parse(sessionStorage.getItem("prompt-atlas-context") || "null");
    } catch (_) { state.token = token || ""; }
    if (hash) history.replaceState(null, "", location.pathname + location.search);
  }

  async function api(path, options = {}) {
    if (isNative()) return window.atlasNativeRequest(path, options);
    const headers = new Headers(options.headers || {});
    if (state.token) headers.set("X-Prompt-Atlas-Token", state.token);
    const response = await fetch(path, { ...options, headers, cache: "no-store", credentials: "same-origin" });
    let data;
    try { data = await response.json(); } catch (_) { throw new Error("本地服务返回了无法读取的数据，请重新打开资料库。"); }
    if (!response.ok) {
      if (response.status === 401 || response.status === 403) throw new Error("访问凭证已失效。请从 Codex 插件重新打开资料库。");
      throw new Error(typeof data.error === "string" ? data.error : "本地服务暂时无法完成请求，请重试。");
    }
    return data;
  }

  function showError(error) {
    const message = error instanceof TypeError ? "连接不到本地资料库。请确认插件服务正在运行，然后重试。" : error.message || "发生了错误，请重试。";
    $("error-banner").textContent = message;
    $("error-banner").hidden = false;
    return message;
  }

  function clearError() { $("error-banner").hidden = true; $("error-banner").textContent = ""; }
  function announce(text) { $("announcements").textContent = text; }
  function toast(text) {
    clearTimeout(state.toastTimer);
    $("toast").textContent = text;
    $("toast").hidden = false;
    state.toastTimer = setTimeout(() => { $("toast").hidden = true; }, 3600);
  }

  function asDate(value) {
    if (value === null || value === undefined || value === "") return null;
    const input = typeof value === "number" && value < 1e12 ? value * 1000 : value;
    const date = new Date(input);
    return Number.isNaN(date.getTime()) ? null : date;
  }

  function dateLabel(value, full = false) {
    const date = asDate(value);
    if (!date) return "时间未知";
    if (full) return new Intl.DateTimeFormat("zh-CN", { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" }).format(date);
    const now = new Date();
    if (date.toDateString() === now.toDateString()) return "今天 " + new Intl.DateTimeFormat("zh-CN", { hour: "2-digit", minute: "2-digit" }).format(date);
    return new Intl.DateTimeFormat("zh-CN", { ...(date.getFullYear() !== now.getFullYear() ? { year: "numeric" } : {}), month: "2-digit", day: "2-digit" }).format(date);
  }

  function number(value) { return new Intl.NumberFormat("zh-CN").format(Number(value) || 0); }
  function roleLabel(role) { return role === "user" ? "我的提问" : role === "assistant" ? "模型回复" : "其他消息"; }

  function highlight(node, value) {
    const text = String(value || "");
    const terms = [...new Set(state.query.trim().split(/\s+/u).filter(Boolean))].sort((a, b) => b.length - a.length);
    if (!terms.length) { node.textContent = text; return; }
    const pattern = new RegExp(terms.map((term) => term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|"), "giu");
    let start = 0;
    for (const match of text.matchAll(pattern)) {
      if (match.index > start) node.append(document.createTextNode(text.slice(start, match.index)));
      node.append(element("mark", "", match[0]));
      start = match.index + match[0].length;
    }
    node.append(document.createTextNode(text.slice(start)));
  }

  function excerpt(value) {
    return String(value || "").replace(/\[([^\]]+)\]\((?:https?|codex):\/\/[^\s)]+\)/g, "$1")
      .replace(/^\s{0,3}#{1,6}\s+/gm, "").replace(/\*\*([^*]+)\*\*/g, "$1")
      .replace(/`([^`]+)`/g, "$1").replace(/\s+/g, " ").trim();
  }

  function inlineText(node, value) {
    const pattern = /\*\*([^*\n]+)\*\*|`([^`\n]+)`|\[([^\]\n]+)\]\(((?:https?|codex):\/\/[^\s)]+)\)/g;
    let start = 0;
    for (const match of value.matchAll(pattern)) {
      const plain = element("span"); highlight(plain, value.slice(start, match.index)); node.append(plain);
      const piece = element(match[1] ? "strong" : match[2] ? "code" : "a");
      highlight(piece, match[1] || match[2] || match[3]);
      if (match[4]) { piece.href = match[4]; piece.target = "_blank"; piece.rel = "noopener noreferrer"; }
      node.append(piece);
      start = match.index + match[0].length;
    }
    const tail = element("span"); highlight(tail, value.slice(start)); node.append(tail);
  }

  function renderBody(node, text, role) {
    if (role === "user") { highlight(node, text); return; }
    node.classList.add("formatted");
    const lines = String(text).split("\n");
    let paragraph = [], code = null, list = null;
    const flush = () => {
      if (paragraph.length) { const p = element("p"); inlineText(p, paragraph.join("\n")); node.append(p); paragraph = []; }
    };
    for (const line of lines) {
      if (/^\s*```/.test(line)) {
        flush(); list = null;
        if (code !== null) { node.append(element("pre", "code-block", code.join("\n"))); code = null; }
        else code = [];
        continue;
      }
      if (code !== null) { code.push(line); continue; }
      if (!line.trim()) { flush(); list = null; continue; }
      const heading = line.match(/^#{1,6}\s+(.+)$/);
      const item = line.match(/^\s*(?:([-*])|\d+\.)\s+(.+)$/);
      if (heading) { flush(); list = null; const h = element("h3"); inlineText(h, heading[1]); node.append(h); }
      else if (item) {
        flush(); const type = item[1] ? "ul" : "ol";
        if (!list || list.tagName.toLowerCase() !== type) { list = element(type); if (type === "ol") list.start = parseInt(line, 10); node.append(list); }
        const li = element("li"); inlineText(li, item[2]); list.append(li);
      } else { list = null; paragraph.push(line); }
    }
    flush();
    if (code !== null) node.append(element("pre", "code-block", code.join("\n")));
  }

  function updateStatus(data) {
    if (!isNative() && typeof state.launchContext?.current_project === "string") {
      const current = state.launchContext.current_project;
      const project = state.projects.find((item) => item.path === current || String(item.id) === current);
      data = { ...data, current_project: current, current_project_name: project?.name || current.split("/").filter(Boolean).pop() || "" };
    }
    state.status = data;
    $("all-count").textContent = number(data.threads);
    $("index-summary").textContent = number(data.threads) + " 个任务 · " + number(data.messages) + " 条消息";
    $("index-summary").title = data.last_indexed ? "上次更新：" + dateLabel(data.last_indexed, true) : "尚未建立索引";
    $("refresh-button").disabled = Boolean(data.indexing);
    $("refresh-button").classList.toggle("indexing", Boolean(data.indexing));
    $("refresh-label").textContent = data.indexing ? "正在更新…" : "更新索引";
    const currentButton = document.querySelector('[data-scope="current"]');
    currentButton.disabled = !data.current_project;
    currentButton.title = data.current_project_name || data.current_project || "当前页面未指定项目";
    const warnings = Array.isArray(data.warnings) ? data.warnings : [];
    $("warning-banner").textContent = warnings.map((warning) => typeof warning === "string" ? warning : String(warning.message || "部分对话暂时无法读取")).join("\n");
    $("warning-banner").hidden = !warnings.length;
    if ((data.indexing || data.ready === false) && !state.polling) schedulePoll();
  }

  function schedulePoll() {
    state.polling = setTimeout(async () => {
      state.polling = null;
      try {
        const data = await api("/api/status");
        updateStatus(data);
        if (!data.indexing && data.ready !== false) {
          await loadProjects();
          await search({ keepSelection: true });
          toast("索引已更新");
        }
      } catch (error) { showError(error); }
    }, 1600);
  }

  async function loadProjects() {
    const data = await api("/api/projects");
    state.projects = Array.isArray(data.projects) ? data.projects : [];
    renderProjects();
  }

  function renderProjects() {
    const list = $("project-list");
    list.replaceChildren();
    $("project-count").textContent = number(state.projects.length);
    if (!state.projects.length) list.append(element("div", "nav-placeholder", "暂时没有项目"));
    for (const project of state.projects) {
      const projectKey = String(project.id ?? project.path ?? "");
      const button = element("button", "project-button");
      button.type = "button";
      button.dataset.project = projectKey;
      const active = state.scope === "project" && (state.project === projectKey || state.project === project.path);
      button.setAttribute("aria-pressed", String(active));
      button.classList.toggle("active", active);
      button.title = project.path || project.name || "未命名项目";
      button.append(element("span", "project-dot"), element("span", "project-name", project.name || project.path || "未命名项目"), element("span", "project-thread-count", number(project.threads)));
      button.addEventListener("click", () => setScope("project", projectKey));
      list.append(button);
    }
  }

  function setScope(scope, project = "") {
    state.scope = scope;
    state.project = scope === "current" ? String(state.status?.current_project || "") : project;
    for (const button of document.querySelectorAll("[data-scope]")) {
      const active = button.dataset.scope === scope;
      button.classList.toggle("active", active);
      button.setAttribute("aria-pressed", String(active));
    }
    const specific = state.projects.find((item) => String(item.id ?? item.path ?? "") === state.project);
    $("scope-title").textContent = scope === "all" ? "所有项目" : scope === "current" ? (state.status?.current_project_name || "当前项目") : (specific?.name || "选定项目");
    renderProjects();
    closeScope();
    $("search-input").focus();
    scheduleSearch(true);
  }

  function closeScope() {
    $("scope-panel").hidden = true;
    $("scope-toggle").setAttribute("aria-expanded", "false");
  }

  function focusResult(result, focus = false) {
    if (!result) return;
    state.selectedId = String(result.id);
    for (const card of $("result-list").querySelectorAll(".result-card")) {
      const selected = card.dataset.messageId === state.selectedId;
      card.setAttribute("aria-current", String(selected));
      if (selected && focus) {
        card.focus({ preventScroll: true });
        card.scrollIntoView({ block: "nearest" });
      }
    }
  }

  function returnToResults(focus = true) {
    state.threadController?.abort();
    state.reading = false;
    document.body.classList.remove("reading");
    $("conversation-panel").setAttribute("aria-busy", "false");
    $("result-list").scrollTop = state.listScroll;
    if (focus) {
      const selected = [...$("result-list").querySelectorAll(".result-card")].find(card => card.dataset.messageId === state.selectedId);
      (selected || $("search-input")).focus({ preventScroll: true });
    }
  }

  function applyLaunchContext(context, runSearch = true) {
    if (!context) return;
    const signature = JSON.stringify([context.current_project, context.project, context.q]);
    if (signature === state.nativeContextSignature) return;
    state.nativeContextSignature = signature;
    if (typeof context.current_project === "string" && state.status) {
      state.status.current_project = context.current_project;
      const current = state.projects.find((item) => item.path === context.current_project || String(item.id) === context.current_project);
      state.status.current_project_name = current?.name || context.current_project.split("/").filter(Boolean).pop() || "";
      updateStatus(state.status);
    }
    if (typeof context.q === "string") $("search-input").value = context.q;
    if (typeof context.project === "string") {
      state.scope = !context.project ? "all" : context.project === context.current_project ? "current" : "project";
      state.project = context.project;
      for (const button of document.querySelectorAll("[data-scope]")) {
        const active = button.dataset.scope === state.scope;
        button.classList.toggle("active", active);
        button.setAttribute("aria-pressed", String(active));
      }
      const specific = state.projects.find((item) => item.path === state.project || String(item.id) === state.project);
      $("scope-title").textContent = state.scope === "all" ? "所有项目" : specific?.name || state.status?.current_project_name || "当前项目";
      renderProjects();
    }
    if (runSearch) scheduleSearch(true);
  }

  function readFilters() {
    state.query = $("search-input").value.trim();
    state.sort = $("sort-select").value;
    state.after = $("date-after").value;
    state.before = $("date-before").value;
    state.archived = $("include-archived").checked;
    state.commentary = $("include-commentary").checked;
    state.subagents = $("include-subagents").checked;
    const count = Number(Boolean(state.after)) + Number(Boolean(state.before)) + Number(!state.archived) + Number(state.commentary) + Number(state.subagents);
    $("filter-count").textContent = String(count);
    $("filter-count").hidden = !count;
  }

  function scheduleSearch(immediate = false) {
    if (state.reading) returnToResults(false);
    clearTimeout(state.debounce);
    state.debounce = null;
    state.searchController?.abort();
    // A newer query also invalidates an in-flight context request.
    state.threadController?.abort();
    state.generation += 1;
    state.offset = 0;
    readFilters();
    if (immediate) search();
    else state.debounce = setTimeout(() => search(), 230);
  }

  async function search({ keepSelection = false } = {}) {
    clearTimeout(state.debounce);
    state.debounce = null;
    state.searchController?.abort();
    const controller = new AbortController();
    state.searchController = controller;
    const generation = ++state.generation;
    readFilters();
    if (state.after && state.before && state.after > state.before) {
      state.searching = false;
      document.querySelector(".results-panel").setAttribute("aria-busy", "false");
      $("conversation-panel").setAttribute("aria-busy", "false");
      $("conversation-content").classList.remove("context-loading");
      $("result-count").textContent = number(state.total) + " 条";
      updatePagination();
      showError(new Error("起始日期不能晚于结束日期，请调整日期范围。"));
      return;
    }
    clearError();
    state.searching = true;
    document.querySelector(".results-panel").setAttribute("aria-busy", "true");
    $("results-heading").textContent = state.query ? "搜索结果" : state.sort === "oldest" ? "历史对话" : "最近的对话";
    $("result-count").textContent = "正在查找…";
    $("previous-page").disabled = true;
    $("next-page").disabled = true;
    const params = new URLSearchParams({ q: state.query, project: state.scope === "all" ? "" : state.project, role: state.role === "all" ? "" : state.role, after: state.after, before: state.before, archived: state.archived ? "1" : "0", commentary: state.commentary ? "1" : "0", subagents: state.subagents ? "1" : "0", sort: state.sort, limit: String(state.limit), offset: String(state.offset) });
    try {
      const data = await api("/api/search?" + params, { signal: controller.signal });
      if (generation !== state.generation) return;
      const oldId = keepSelection ? state.selectedId : null;
      state.results = Array.isArray(data.results) ? data.results : [];
      state.total = Number(data.total) || 0;
      state.offset = Number(data.offset) || 0;
      state.selectedId = null;
      $("result-count").textContent = number(state.total) + " 条";
      renderResults();
      updatePagination();
      announce("找到 " + number(state.total) + " 条消息");
      const selected = state.results.find((item) => String(item.id) === String(oldId)) || state.results[0];
      if (selected) focusResult(selected);
      else clearConversation();
    } catch (error) {
      if (error.name === "AbortError" || generation !== state.generation) return;
      state.results = [];
      state.total = 0;
      state.selectedId = null;
      $("result-count").textContent = "读取失败";
      const message = showError(error);
      renderResults(message);
      updatePagination();
      clearConversation();
    } finally {
      if (generation === state.generation) {
        state.searching = false;
        document.querySelector(".results-panel").setAttribute("aria-busy", "false");
      }
    }
  }

  function renderResults(error) {
    const list = $("result-list");
    list.replaceChildren();
    if (!state.results.length) {
      const empty = element("div", "empty-state");
      empty.append(element("h3", "", error ? "暂时没能读到对话" : "没有找到匹配的消息"));
      empty.append(element("p", "", error || (state.query ? "换一个关键词，或试着放宽筛选范围。\n中文与英文都可以直接搜索。" : "试着选择所有项目、放宽筛选，\n或更新索引以读取最新对话。")));
      if (error) { const retry = element("button", "error-retry", "重试"); retry.type = "button"; retry.addEventListener("click", () => search()); empty.append(retry); }
      list.append(empty);
      return;
    }
    const fragment = document.createDocumentFragment();
    for (const result of state.results) {
      const button = element("button", "result-card");
      button.type = "button";
      button.dataset.messageId = String(result.id);
      button.setAttribute("aria-current", "false");
      const meta = element("div", "result-card-meta");
      const role = result.role === "user" ? "user" : "assistant";
      button.classList.add(role);
      meta.append(element("span", "role-tag " + role, roleLabel(result.role)));
      if (result.channel === "commentary") meta.append(element("span", "", "过程说明"));
      meta.append(element("span", "result-project", result.project_name || "无项目"));
      const time = element("time", "result-date", dateLabel(result.timestamp));
      const date = asDate(result.timestamp);
      if (date) time.dateTime = date.toISOString();
      meta.append(time);
      const title = element("h3", "", result.title || "未命名任务");
      const snippet = element("p", "result-snippet");
      highlight(snippet, excerpt(result.snippet || result.text || "（空消息）"));
      if (result.archived) meta.append(element("span", "archived-tag", "已归档"));
      button.append(snippet);
      const clean = text => String(text || "").replace(/\s+/gu, "").replace(/…/gu, "");
      if (clean(result.title) !== clean(result.snippet) && clean(result.title) !== clean(result.text)) button.append(title);
      button.append(meta);
      button.addEventListener("click", () => selectResult(result, false, true));
      button.addEventListener("keydown", (event) => {
        if (!["ArrowDown", "ArrowUp", "Home", "End"].includes(event.key)) return;
        event.preventDefault();
        const index = state.results.findIndex((item) => String(item.id) === String(result.id));
        if (event.key === "ArrowUp" && index === 0) { $("search-input").focus(); return; }
        const next = event.key === "Home" ? 0 : event.key === "End" ? state.results.length - 1 : Math.max(0, Math.min(state.results.length - 1, index + (event.key === "ArrowDown" ? 1 : -1)));
        focusResult(state.results[next], true);
      });
      fragment.append(button);
    }
    list.append(fragment);
    list.scrollTop = 0;
  }

  function updatePagination() {
    $("pagination").hidden = state.total <= state.limit;
    $("previous-page").disabled = state.offset <= 0;
    $("next-page").disabled = state.offset + state.limit >= state.total;
    $("page-label").textContent = (Math.floor(state.offset / state.limit) + 1) + " / " + Math.max(1, Math.ceil(state.total / state.limit));
  }

  function clearConversation() {
    if (state.reading) returnToResults(false);
    state.threadController?.abort();
    state.thread = null;
    state.selectedId = null;
    $("conversation-content").hidden = true;
    $("conversation-empty").hidden = false;
    $("conversation-panel").setAttribute("aria-busy", "false");
    document.querySelector(".conversation-error")?.remove();
  }

  async function selectResult(result, focus, revealContext = false) {
    if (!result) return;
    if (!state.reading) state.listScroll = $("result-list").scrollTop;
    focusResult(result, focus);
    state.reading = true;
    closeScope();
    document.body.classList.add("reading");
    $("open-task").hidden = true;
    $("conversation-content").hidden = true;
    $("conversation-empty").hidden = false;
    $("back-to-results").focus({ preventScroll: true });
    state.threadController?.abort();
    const controller = new AbortController();
    state.threadController = controller;
    const selection = state.selectedId;
    const generation = state.generation;
    $("conversation-panel").setAttribute("aria-busy", "true");
    $("conversation-content").classList.add("context-loading");
    document.querySelector(".conversation-error")?.remove();
    try {
      const params = new URLSearchParams({ id: String(result.thread_id), message: selection, limit: "101" });
      const data = await api("/api/thread?" + params, { signal: controller.signal });
      if (controller.signal.aborted || selection !== state.selectedId || generation !== state.generation) return;
      state.thread = { ...data, messages: Array.isArray(data.messages) ? data.messages : [] };
      state.threadStart = Number(data.offset) || 0;
      state.threadEnd = state.threadStart + state.thread.messages.length;
      state.hasBefore = Boolean(data.has_more_before);
      state.hasAfter = Boolean(data.has_more_after);
      renderConversation();
      requestAnimationFrame(scrollToMatch);
    } catch (error) {
      if (error.name === "AbortError" || selection !== state.selectedId || generation !== state.generation) return;
      $("conversation-content").hidden = true;
      $("conversation-empty").hidden = true;
      const wrapper = element("div", "conversation-error");
      const empty = element("div", "empty-state");
      empty.append(element("h3", "", "上下文暂时无法读取"), element("p", "", error.message || "请重试。"));
      const retry = element("button", "error-retry", "重新加载");
      retry.type = "button";
      retry.addEventListener("click", () => selectResult(result, false, revealContext));
      empty.append(retry); wrapper.append(empty); $("conversation-panel").append(wrapper);
    } finally {
      if (selection === state.selectedId && generation === state.generation) {
        $("conversation-content").classList.remove("context-loading");
        $("conversation-panel").setAttribute("aria-busy", "false");
      }
    }
  }

  function renderConversation() {
    const thread = state.thread;
    $("conversation-empty").hidden = true;
    $("conversation-content").hidden = false;
    $("conversation-project").textContent = thread.project_name || thread.project || "无项目";
    $("conversation-title").textContent = thread.title || "未命名任务";
    $("conversation-title").title = thread.title || "未命名任务";
    const link = $("open-task");
    let validLink = false;
    try { validLink = new URL(thread.deep_link).protocol === "codex:"; } catch (_) { /* No link is better than an untrusted URL. */ }
    link.hidden = !validLink;
    if (validLink) link.href = thread.deep_link;
    else link.removeAttribute("href");
    const visibleMessages = thread.messages.filter(message => state.commentary || message.channel !== "commentary");
    $("context-count").textContent = number(visibleMessages.length) + " 条消息";
    const fragment = document.createDocumentFragment();
    for (const message of visibleMessages) {
      const role = message.role === "user" ? "user" : "assistant";
      const matched = String(message.id) === state.selectedId;
      const article = element("article", "message " + role + (matched ? " matched" : ""));
      article.dataset.messageId = String(message.id);
      if (matched) article.setAttribute("aria-label", "匹配消息：" + roleLabel(message.role));
      const header = element("header", "message-header");
      header.append(element("span", "message-role", roleLabel(message.role)));
      if (message.channel === "commentary") header.append(element("span", "message-channel", "过程说明"));
      const time = element("time", "message-time", dateLabel(message.timestamp, true));
      const date = asDate(message.timestamp);
      if (date) time.dateTime = date.toISOString();
      header.append(time);
      if (matched) header.append(element("span", "matched-label", "匹配消息"));
      const copy = element("button", "copy-button", "复制");
      copy.type = "button";
      copy.setAttribute("aria-label", "复制这条" + roleLabel(message.role));
      copy.addEventListener("click", () => copyMessage(String(message.text || "")));
      header.append(copy);
      const body = element("div", "message-body");
      renderBody(body, message.text || "（空消息）", role);
      article.append(header, body);
      fragment.append(article);
    }
    $("messages").replaceChildren(fragment);
    $("load-before").hidden = !state.hasBefore;
    $("load-after").hidden = !state.hasAfter;
    $("jump-match").disabled = !thread.messages.some((message) => String(message.id) === state.selectedId);
  }

  function scrollToMatch() {
    const matched = $("messages").querySelector(".matched");
    if (!matched) return;
    const scroll = $("conversation-scroll");
    scroll.scrollTo({ top: matched.offsetTop - scroll.offsetTop - 20, behavior: "auto" });
  }

  async function loadContext(direction) {
    if (!state.thread || state.loadingContext) return;
    state.loadingContext = true;
    const threadId = state.thread.id;
    const selection = state.selectedId;
    const generation = state.generation;
    const button = $(direction === "before" ? "load-before" : "load-after");
    const oldLabel = button.textContent;
    button.textContent = "正在加载…";
    button.disabled = true;
    const offset = direction === "before" ? Math.max(0, state.threadStart - 101) : state.threadEnd;
    const scroll = $("conversation-scroll");
    const oldHeight = scroll.scrollHeight;
    const oldTop = scroll.scrollTop;
    try {
      const data = await api("/api/thread?" + new URLSearchParams({ id: String(threadId), offset: String(offset), limit: "101" }));
      if (state.thread?.id !== threadId || state.selectedId !== selection || generation !== state.generation) return;
      const incoming = Array.isArray(data.messages) ? data.messages : [];
      const arranged = direction === "before" ? [...incoming, ...state.thread.messages] : [...state.thread.messages, ...incoming];
      const seen = new Set();
      state.thread.messages = arranged.filter((item) => { const id = String(item.id); if (seen.has(id)) return false; seen.add(id); return true; });
      const start = Number(data.offset) || 0;
      if (direction === "before") { state.threadStart = Math.min(state.threadStart, start); state.hasBefore = Boolean(data.has_more_before); }
      else { state.threadEnd = Math.max(state.threadEnd, start + incoming.length); state.hasAfter = Boolean(data.has_more_after); }
      renderConversation();
      if (direction === "before") scroll.scrollTop = oldTop + scroll.scrollHeight - oldHeight;
      else scroll.scrollTop = oldTop;
    } catch (error) { toast(error.message || "加载失败，请重试。"); }
    finally { state.loadingContext = false; button.textContent = oldLabel; button.disabled = false; }
  }

  async function copyMessage(text) {
    try {
      if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(text);
      else {
        const field = element("textarea", "sr-only");
        field.value = text;
        field.setAttribute("aria-label", "临时复制内容");
        document.body.append(field);
        const previous = document.activeElement;
        field.select();
        const copied = document.execCommand("copy");
        field.remove();
        previous?.focus({ preventScroll: true });
        if (!copied) throw new Error("copy");
      }
      toast("消息已复制");
    } catch (_) { toast("浏览器未允许复制。你可以直接选中文字，再按复制快捷键。"); }
  }

  async function refresh() {
    if ($("refresh-button").disabled) return;
    $("refresh-button").disabled = true;
    $("refresh-label").textContent = "正在更新…";
    $("refresh-button").classList.add("indexing");
    clearError();
    try {
      const data = await api("/api/refresh", { method: "POST" });
      updateStatus(data);
      if (!data.indexing) { await loadProjects(); await search({ keepSelection: true }); toast("索引已更新"); }
    } catch (error) {
      showError(error);
      $("refresh-button").disabled = false;
      $("refresh-label").textContent = "更新索引";
      $("refresh-button").classList.remove("indexing");
    }
  }

  function resetFilters() {
    $("date-after").value = "";
    $("date-before").value = "";
    $("include-archived").checked = true;
    $("include-commentary").checked = false;
    $("include-subagents").checked = false;
    scheduleSearch(true);
  }

  function bindEvents() {
    $("search-shortcut").textContent = /Mac|iPhone|iPad/.test(navigator.platform) ? "⌘ K" : "Ctrl K";
    $("search-form").addEventListener("submit", (event) => { event.preventDefault(); scheduleSearch(true); });
    $("search-input").addEventListener("input", (event) => { if (!event.isComposing) scheduleSearch(); });
    $("search-input").addEventListener("compositionend", () => scheduleSearch());
    $("search-input").addEventListener("keydown", (event) => {
      if (event.key === "ArrowDown" && state.results.length && !state.searching && !state.debounce) { event.preventDefault(); focusResult(state.results[0], true); }
      if (event.key === "Enter" && !event.isComposing && state.results.length && !state.searching && !state.debounce) {
        event.preventDefault();
        const result = state.results.find(item => String(item.id) === state.selectedId) || state.results[0];
        selectResult(result, false, true);
      }
      if (event.key === "Escape") $("search-input").blur();
    });
    document.addEventListener("keydown", (event) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        if (state.reading) returnToResults(false);
        closeScope();
        $("search-input").focus(); $("search-input").select();
      }
      if (event.key === "Escape") {
        if (!$("scope-panel").hidden) { closeScope(); $("scope-toggle").focus(); }
        else if (state.reading) returnToResults();
        else if (!$("advanced-filters").hidden) { $("advanced-filters").hidden = true; $("filter-toggle").setAttribute("aria-expanded", "false"); $("filter-toggle").focus(); }
      }
    });
    $("scope-toggle").addEventListener("click", () => {
      const open = $("scope-panel").hidden;
      $("scope-panel").hidden = !open;
      $("scope-toggle").setAttribute("aria-expanded", String(open));
    });
    document.addEventListener("click", event => {
      if (!$("scope-panel").hidden && !$("scope-panel").contains(event.target) && !$("scope-toggle").contains(event.target)) closeScope();
    });
    for (const button of document.querySelectorAll("[data-scope]")) button.addEventListener("click", () => setScope(button.dataset.scope));
    for (const button of document.querySelectorAll("[data-role]")) button.addEventListener("click", () => {
      state.role = button.dataset.role;
      for (const item of document.querySelectorAll("[data-role]")) { const active = item === button; item.classList.toggle("active", active); item.setAttribute("aria-pressed", String(active)); }
      scheduleSearch(true);
    });
    for (const id of ["sort-select", "date-after", "date-before", "include-archived", "include-commentary", "include-subagents"]) $(id).addEventListener("change", () => scheduleSearch(true));
    $("filter-toggle").addEventListener("click", () => { const expanded = $("filter-toggle").getAttribute("aria-expanded") !== "true"; $("filter-toggle").setAttribute("aria-expanded", String(expanded)); $("advanced-filters").hidden = !expanded; });
    $("reset-filters").addEventListener("click", resetFilters);
    $("refresh-button").addEventListener("click", refresh);
    $("previous-page").addEventListener("click", () => { if (!state.searching) { state.offset = Math.max(0, state.offset - state.limit); search(); } });
    $("next-page").addEventListener("click", () => { if (!state.searching) { state.offset += state.limit; search(); } });
    $("jump-match").addEventListener("click", scrollToMatch);
    $("back-to-results").addEventListener("click", () => returnToResults());
    $("load-before").addEventListener("click", () => loadContext("before"));
    $("load-after").addEventListener("click", () => loadContext("after"));
    $("open-task").addEventListener("click", async (event) => {
      if (!isNative()) return;
      event.preventDefault();
      try { await window.atlasNativeOpenThread(state.thread?.id); }
      catch (error) { toast(error.message || "暂时无法打开原任务。"); }
    });
    document.querySelector(".brand").addEventListener("click", (event) => {
      event.preventDefault();
      $("search-input").value = "";
      setScope("all");
      $("search-input").focus();
    });
    window.addEventListener("atlas:native-context", (event) => {
      if (state.ready) applyLaunchContext(event.detail);
    });
    window.addEventListener("pagehide", () => { clearTimeout(state.polling); state.searchController?.abort(); state.threadController?.abort(); });
  }

  async function boot() {
    initializeTheme();
    initializeToken();
    bindEvents();
    try {
      if (isNative()) await window.atlasNativeReady;
      const results = await Promise.allSettled([api("/api/status"), loadProjects()]);
      if (results[0].status === "fulfilled") updateStatus(results[0].value);
      else throw results[0].reason;
      if (results[1].status === "rejected") throw results[1].reason;
      state.ready = true;
      if (isNative()) applyLaunchContext(window.atlasNativeContext(), false);
      else if (state.launchContext) applyLaunchContext(state.launchContext, false);
      if (state.status?.ready !== false) await search();
    } catch (error) {
      const message = showError(error);
      $("result-count").textContent = "连接失败";
      $("index-summary").textContent = "本地索引暂不可用";
      renderResults(message);
    }
  }

  boot();
})();
